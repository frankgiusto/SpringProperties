package ca.gc.ic.cipo.common.config;

import javax.annotation.PostConstruct;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ca.gc.ic.cipo.common.config.encryption.CipoDecrypt;

public class ReloadableProperties {

    private static final Logger log = LoggerFactory.getLogger(ReloadableProperties.class);

    private CipoDecrypt decryptor;

    private PropertiesConfiguration configuration;

    private String filePath;

    private Integer refreshDelay = 1000;

    @PostConstruct
    public void init() {

        log.info("hello");
        if (StringUtils.isNotBlank(filePath)) {

            log.info("Loading the properties file: " + filePath);
            try {
                configuration = new PropertiesConfiguration(filePath);
                FileChangedReloadingStrategy fileChangedReloadingStrategy = new FileChangedReloadingStrategy();
                fileChangedReloadingStrategy.setRefreshDelay(refreshDelay);
                configuration.setReloadingStrategy(fileChangedReloadingStrategy);

            } catch (ConfigurationException e) {
                log.error("Error loading properties file.", e);
            }
        }
    }

    public String getProperty(String key) {
        return decryptor.decryptValue((String) configuration.getProperty(key));
    }

    public void setProperty(String key, Object value) {
        configuration.setProperty(key, value);
    }

    public void save() {
        try {
            configuration.save();
        } catch (ConfigurationException e) {
            e.printStackTrace();
        }
    }

    public Integer getRefreshDelay() {
        return refreshDelay;
    }

    public void setRefreshDelay(Integer refreshDelay) {
        this.refreshDelay = refreshDelay;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public CipoDecrypt getDecryptor() {
        return decryptor;
    }

    public void setDecryptor(CipoDecrypt decryptor) {
        this.decryptor = decryptor;
    }

}
