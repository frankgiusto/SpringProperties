package ca.gc.ic.cipo.common.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.configuration.DatabaseConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springmodules.commons.configuration.CommonsConfigurationFactoryBean;

import ca.gc.ic.cipo.common.config.encryption.CipoDecrypt;

/**
 * Initialize Spring Environment with application and database properties. Database properties will take precedence
 * unless developer places the file 'cipo-db-configuration-override.properties' in the classpath with key/value pairs he
 * wishes to override.
 */
@Configuration
@PropertySources({@PropertySource(value = "classpath:common-config-module.properties", ignoreResourceNotFound = false),
    @PropertySource(value = "classpath:cipo-jndi-datasource-configuration.properties", ignoreResourceNotFound = false), // ??????
    @PropertySource(value = "classpath:cipo-local-configuration-override.properties", ignoreResourceNotFound = true)})

public class SpringPropertiesConfig extends PropertySourcesPlaceholderConfigurer
    implements EnvironmentAware, InitializingBean {

    private static final Logger log = LoggerFactory.getLogger(SpringPropertiesConfig.class);

    private static final String LOCAL_CONFIGURATION_OVERRIDE_PROPERTIES = "class path resource [cipo-db-configuration-override.properties]";

    CipoDecrypt cipoDecrypt = new CipoDecrypt();

    private Environment environment;

    @Override
    public void setEnvironment(Environment environment) {
        // save off Environment for later use
        this.environment = environment;
        super.setEnvironment(environment);
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        MutablePropertySources envPropSources = ((ConfigurableEnvironment) environment).getPropertySources();

        try {
            // dataSource, Table Name, Key Column, Value Column
            DatabaseConfiguration databaseConfiguration = new DatabaseConfiguration(mydataSource(),
                environment.getProperty("config.table.name"), environment.getProperty("config.table.key"),
                environment.getProperty("config.table.value"));

            // Database Properties
            CommonsConfigurationFactoryBean commonsConfigurationFactoryBean = new CommonsConfigurationFactoryBean(
                databaseConfiguration);
            Properties dbProps = (Properties) commonsConfigurationFactoryBean.getObject();
            PropertiesPropertySource dbPropertySource = new PropertiesPropertySource("dbPropertySource", dbProps);

            // File Properties
            // if (StringUtils.isNotBlank(reloadablePropertiesFilename)) {
            // PropertiesConfiguration fileConfiguration = new PropertiesConfiguration(reloadablePropertiesFilename);
            // FileChangedReloadingStrategy fileChangedReloadingStrategy = new FileChangedReloadingStrategy();
            // fileChangedReloadingStrategy.setRefreshDelay(1000);
            // fileConfiguration.setReloadingStrategy(fileChangedReloadingStrategy);

            // CompositeConfiguration fileCompositeConfig = new CompositeConfiguration();
            // fileCompositeConfig.addConfiguration(reloadableProperties);
            // Properties fileProperties = ConfigurationConverter.getProperties(fileCompositeConfig);

            // }
            // PropertiesPropertySource filePropertySource = new PropertiesPropertySource("filePropertySource",
            // fileProperties);
            // envPropSources.addLast(filePropertySource);

            // If the database configuration values are overridden, then add them last
            if (envPropSources.contains(LOCAL_CONFIGURATION_OVERRIDE_PROPERTIES)) {
                envPropSources.addLast(dbPropertySource);
            } else {
                envPropSources.addFirst(dbPropertySource);
            }

            // Decrypt
            cipoDecrypt.decryptEnvironment(envPropSources);

        } catch (Exception e) {
            log.error("Error during database properties setup", e);
            throw new RuntimeException(e);
        }

    }

    // 1- Load JNDI configuration – secure information.
    // Context context = new InitialContext();
    // JNDIConfiguration jndiConfig = new JNDIConfiguration(context, prefix);

    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    public DataSource mydataSource() {
        final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
        dsLookup.setResourceRef(true);
        DataSource dataSource = dsLookup.getDataSource(environment.getProperty("config.jndiName"));
        return dataSource;
    }
}