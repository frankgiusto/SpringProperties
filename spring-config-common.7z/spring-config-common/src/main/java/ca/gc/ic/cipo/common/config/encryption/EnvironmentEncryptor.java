package ca.gc.ic.cipo.common.config.encryption;

/**
 * Service interface for decrypting properties in Environment object.
 *
 * @author Bartosz Wojtkiewicz
 * @author Rafal Zukowski
 *
 */
public interface EnvironmentEncryptor {

    Environment decrypt(Environment environment);

    String decyrpt(String encrytedString);
}
