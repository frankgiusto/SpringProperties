package ca.gc.ic.cipo.common.config.encryption;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;;

/**
 * EnvironmentEncryptor that can decrypt property values prefixed with {cipher} marker.
 *
 * @author Dave Syer
 * @author Bartosz Wojtkiewicz
 * @author Rafal Zukowski
 *
 */
public class CipherEnvironmentEncryptor implements EnvironmentEncryptor {

    private static final Logger log = LoggerFactory.getLogger(CipherEnvironmentEncryptor.class);

    private static final String KEY = "1Hbfh667adfDEJ78";

    private EnvironmentPrefixHelper helper = new EnvironmentPrefixHelper();

    public CipherEnvironmentEncryptor() {
    }

    @Override
    public Environment decrypt(Environment environment) {
        Environment result = new Environment(environment);
        for (PropertySource source : environment.getPropertySources()) {
            Map<Object, Object> map = new LinkedHashMap<Object, Object>(source.getSource());
            for (Map.Entry<Object, Object> entry : new LinkedHashSet<>(map.entrySet())) {
                Object key = entry.getKey();
                String name = key.toString();
                String value = entry.getValue().toString();
                if (value.startsWith("{cipher}")) {
                    map.remove(key);
                    try {
                        value = value.substring("{cipher}".length());

                        // value = SimpleCrypto.decrypt(KEY, this.helper.stripPrefix(value));
                        value = AESCrypt.decrypt(this.helper.stripPrefix(value));

                    } catch (Exception e) {
                        value = "<n/a>";
                        name = "invalid." + name;
                        String message = "Cannot decrypt key: " + key + " (" + e.getClass() + ": " + e.getMessage()
                            + ")";
                        if (log.isDebugEnabled()) {
                            log.debug(message, e);
                        } else if (log.isWarnEnabled()) {
                            log.warn(message);
                        }
                    }
                    map.put(name, value);
                }
            }
            result.add(new PropertySource(source.getName(), map));
        }
        return result;
    }

    @Override
    public String decyrpt(String encrytedString) {
        String value = encrytedString;
        try {
            if (encrytedString.startsWith("{cipher}")) {

                value = AESCrypt.decrypt(this.helper.stripPrefix(value));

            }
        } catch (Exception e) {
            log.error("Unable to decrypt '" + encrytedString + "'", e);
            value = "<n/a>";

        }
        return value;
    }

}
