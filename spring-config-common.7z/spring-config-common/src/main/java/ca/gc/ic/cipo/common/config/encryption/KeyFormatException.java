package ca.gc.ic.cipo.common.config.encryption;

@SuppressWarnings("serial")
public class KeyFormatException extends RuntimeException {
}