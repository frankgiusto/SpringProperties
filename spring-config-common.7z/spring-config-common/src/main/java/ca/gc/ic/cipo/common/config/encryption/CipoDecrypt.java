package ca.gc.ic.cipo.common.config.encryption;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;

public class CipoDecrypt {

    private static final Logger log = LoggerFactory.getLogger(CipoDecrypt.class);

    EnvironmentEncryptor encryptor = new CipherEnvironmentEncryptor();

    public void decryptEnvironment(MutablePropertySources envPropSources) {

        Iterator<PropertySource<?>> iterator = envPropSources.iterator();
        while (iterator.hasNext()) {
            PropertySource<?> propertySource = iterator.next();

            if (propertySource instanceof PropertiesPropertySource) {
                log.debug("property s source " + propertySource.getName());
                try {
                    ca.gc.ic.cipo.common.config.encryption.PropertySource configPropertySource = new ca.gc.ic.cipo.common.config.encryption.PropertySource(
                        propertySource.getName(), (Map<?, ?>) propertySource.getSource());

                    Environment environment = new Environment("name", "profile", "label");
                    environment.getPropertySources().add(configPropertySource);
                    List<ca.gc.ic.cipo.common.config.encryption.PropertySource> decryptedPropertySources = this.encryptor
                        .decrypt(environment).getPropertySources();

                    for (ca.gc.ic.cipo.common.config.encryption.PropertySource decryptedPropertySource : decryptedPropertySources) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> originalMap = (Map<String, Object>) propertySource.getSource();
                        @SuppressWarnings("unchecked")
                        Map<String, Object> dcryptedPropeties = (Map<String, Object>) decryptedPropertySource
                            .getSource();
                        originalMap.putAll(dcryptedPropeties);
                    }

                } catch (Exception e) {
                    log.error("property source NOT handled", e);
                }
            }
        }
    }

    public String decryptValue(String encrypted) {
        return this.encryptor.decyrpt(encrypted);
    }
}
